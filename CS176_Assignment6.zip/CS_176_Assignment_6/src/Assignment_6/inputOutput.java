package Assignment_6;

import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;
import java.io.File;

public class inputOutput {

	public static void main(String[] args) throws FileNotFoundException{
		// TODO Auto-generated method stub

		File inputPop=new File("C:\\Users\\12019\\eclipse-workspace\\CS_176_Assignment_6\\src\\Assignment_6\\world_pop_density.txt");
		File inputCountNames = new File("C:\\Users\\12019\\eclipse-workspace\\CS_176_Assignment_6\\src\\Assignment_6\\worldarea.txt");
		
		Scanner in =new Scanner(inputPop);
		Scanner in2 = new Scanner(inputCountNames);
	
	
		PrintWriter outputTxt = new PrintWriter ("C:\\Users\\12019\\eclipse-workspace\\CS_176_Assignment_6\\src\\Assignment_6\\world_output.txt"); 
		
	
		System.out.println(inputPop.exists());
		System.out.println(inputCountNames.exists());
		System.out.println(inputPop.getAbsolutePath());
		System.out.println(inputCountNames.getAbsolutePath());
		//double 
		in.useDelimiter(" ");
		in2.useDelimiter(" ");
		
		double density = 0;
		int i = 0;
		double populationValue = 0;
		double areaValue = 0;
		while (in.hasNext() || in2.hasNext()) {
			String line = in.nextLine();
			String line2 = in2.nextLine();
			System.out.println(line);
			System.out.println(line2);
			
			
			int locationFirstDigit=0; 
			char eachCharacter2=line2.charAt(i); 
			
			
			char eachCharacter1=line.charAt(i);
			
			while(!Character.isDigit(eachCharacter1))  
			{
				locationFirstDigit=locationFirstDigit+1;
				i=i+1;
				eachCharacter1=line.charAt(i++);
				areaValue = eachCharacter1;
				System.out.printf("%.2f\n", areaValue);
				
				
			
			}	 
			
			density = eachCharacter1/eachCharacter2;
			while(!Character.isDigit(eachCharacter2))  
				//check whether each character is not a digit
			{
				locationFirstDigit=locationFirstDigit+1;
				i=i+1;
				eachCharacter2=line2.charAt(i);
				populationValue = eachCharacter2;
				System.out.printf("%.2f\n", (density));
				
			}	 
			
			String country=line2.substring(0,locationFirstDigit); 
			//extract a substring till the first digit
			String area = line2.substring(locationFirstDigit); 
			//extract a substring from the first digit
			double areaVal=Double.parseDouble(area); 
			//convert a string of digits to a double value	
		
			int locationFirstLetter=0; 
			//the first digit's index
			char eachChar; 
			while(!Character.isAlphabetic(line.charAt(i)))  
			{
				locationFirstLetter=locationFirstLetter+1;
				
				i=i+1;
				eachChar=line.charAt(i);
				
				System.out.printf("%-2s", country);
			}	 
			
		}
		
	}	

}
		

